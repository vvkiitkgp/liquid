package com.scb.newton;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiquidityGroupsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiquidityGroupsApplication.class, args);
	}

}
