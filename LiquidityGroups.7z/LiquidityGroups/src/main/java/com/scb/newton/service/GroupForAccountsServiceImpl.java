package com.scb.newton.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.scb.newton.bean.AccountsInfo;
import com.scb.newton.bean.Checkerportal;
import com.scb.newton.bean.GroupsInfo;
import com.scb.newton.dao.GroupForAccountsDao;

@Service
public class GroupForAccountsServiceImpl implements GroupsForAccountsService{

	@Autowired
	GroupForAccountsDao gfadao;
	
	


	@Override
	public int updateGroupWithAccountId(AccountsInfo ai) {
		// TODO Auto-generated method stub
		return gfadao.updateGroupWithAccountId(ai);
	}




	@Override
	public List<AccountsInfo> getAccountDataInState(AccountsInfo ai) {
		// TODO Auto-generated method stub
		return gfadao.getAccountDataInState(ai);
	}
	
	@Override
	public List<GroupsInfo> getGroupDataInState(GroupsInfo ai) {
		// TODO Auto-generated method stub
		return gfadao.getGroupDataInState(ai);
	}

	@Override
	public int addGroupButtonHandler(GroupsInfo gi)
	{
		return gfadao.addGroupButtonHandler(gi);
	}




	@Override
	public List<Checkerportal> getPendingWork(Checkerportal cp) {
		
		
		return gfadao.getPendingWork(cp);
	}




	@Override
	public int changeRequestedStatus(Checkerportal cp) {
		
		return gfadao.changeRequestedStatus(cp); 
	}
}
