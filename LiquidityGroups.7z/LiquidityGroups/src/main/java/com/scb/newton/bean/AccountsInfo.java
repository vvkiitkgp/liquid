package com.scb.newton.bean;

public class AccountsInfo {

	
	private String accountId;
	private String groupId;
	private boolean activeAccount;
	private String customer;
	private int numberOfTransactions;
	private double totalBalance;
	private String currency;
	private boolean baseAccountBoolean;
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public boolean isActiveAccount() {
		return activeAccount;
	}
	public void setActiveAccount(boolean activeAccount) {
		this.activeAccount = activeAccount;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public int getNumberOfTransactions() {
		return numberOfTransactions;
	}
	public void setNumberOfTransactions(int numberOfTransactions) {
		this.numberOfTransactions = numberOfTransactions;
	}
	public double getTotalBalance() {
		return totalBalance;
	}
	public void setTotalBalance(double totalBalance) {
		this.totalBalance = totalBalance;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public boolean isBaseAccountBoolean() {
		return baseAccountBoolean;
	}
	public void setBaseAccountBoolean(boolean baseAccountBoolean) {
		this.baseAccountBoolean = baseAccountBoolean;
	}
	
	
	
	
	

}
