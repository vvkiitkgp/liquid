package com.scb.newton.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.scb.newton.bean.AccountsInfo;
import com.scb.newton.bean.Checkerportal;
import com.scb.newton.bean.GroupsInfo;

public interface GroupsForAccountsService {

	public int updateGroupWithAccountId(AccountsInfo ai);
	
	public List<AccountsInfo> getAccountDataInState(AccountsInfo ai);
	
	public List<GroupsInfo> getGroupDataInState(GroupsInfo ai);
	
	public int addGroupButtonHandler(GroupsInfo gi);
	
	public List<Checkerportal> getPendingWork(Checkerportal cp);
	
	public int changeRequestedStatus(Checkerportal cp);
}
