package com.scb.newton.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import org.springframework.stereotype.Repository;


import com.scb.newton.bean.AccountsInfo;
import com.scb.newton.bean.Checkerportal;
import com.scb.newton.bean.GroupsInfo;

@Repository
public class GroupForAccountsDaoImpl implements GroupForAccountsDao{

	@Autowired
	JdbcTemplate jdbctemplate;
	

	@Override
	public int updateGroupWithAccountId(AccountsInfo ai) {
	String onHitParticularGroupHandlerstmt="update \"accountInfo\" set \"groupId\"=? where \"accountId\"=? ";
		
		return jdbctemplate.update(onHitParticularGroupHandlerstmt,new Object[]{ai.getGroupId(),ai.getAccountId()});
	}


	@Override
	public List<AccountsInfo> getAccountDataInState(AccountsInfo ai)
	{
		
		String listGroupsForAccountsQuery="select * from \"accountInfo\" where customer='"+ai.getCustomer()+"';  ";
		
		
		return jdbctemplate.query(listGroupsForAccountsQuery, new AccountsMapper());

	}

	 class AccountsMapper implements RowMapper<AccountsInfo>{
		 
		 @Override
		 public AccountsInfo mapRow(ResultSet rs,int rowNum) throws SQLException{
			 AccountsInfo accinfo=new AccountsInfo();
			 
			 	accinfo.setAccountId(rs.getString("accountId"));
			 	accinfo.setGroupId(rs.getString("groupId"));
			 	accinfo.setActiveAccount(rs.getBoolean("activeAccount"));
			 	accinfo.setCustomer(rs.getString("customer"));
			 	accinfo.setNumberOfTransactions(rs.getInt("numberOfTransactions"));
				accinfo.setTotalBalance(rs.getDouble("totalBalance"));
				accinfo.setCurrency(rs.getString("currency"));
				accinfo.setBaseAccountBoolean(rs.getBoolean("baseAccountBoolean"));
				return accinfo;
			 
		 }
	 }		
	 
	 
	 
	 @Override
		public List<GroupsInfo> getGroupDataInState(GroupsInfo ai)
		{
			
			String listGroupsForAccountsQuery="select * from \"groupInfo\" where customer='"+ai.getCustomer()+"';  ";
			
			
			return jdbctemplate.query(listGroupsForAccountsQuery, new GroupsMapper());

		}

		 class GroupsMapper implements RowMapper<GroupsInfo>{
			 
			 @Override
			 public GroupsInfo mapRow(ResultSet rs,int rowNum) throws SQLException{
				 GroupsInfo grpinfo=new GroupsInfo();
				 
				 
				 	grpinfo.setGroupId(rs.getString("groupId"));
				 	grpinfo.setProductId(rs.getString("productId"));
				 	grpinfo.setBonusStatus(rs.getString("bonusStatus"));
				 	grpinfo.setBonusValue(rs.getDouble("bonusValue"));
				 	grpinfo.setBaseCurrency(rs.getString("baseCurrency"));
				 	grpinfo.setBaseAccount(rs.getString("baseAccount"));
				 	grpinfo.setCustomer(rs.getString("customer"));
				
					
					return grpinfo;
				 
			 }
		 }



		@Override
		public int addGroupButtonHandler(GroupsInfo gi) {
			
			String addGroupstmt="insert into \"groupInfo\"(\"groupId\",customer) values (?,?) ";
			
			
			return jdbctemplate.update(addGroupstmt,new Object[]{gi.getGroupId(),gi.getCustomer()});
		}


		@Override
		public List<Checkerportal> getPendingWork(Checkerportal cp) {
		
	   String pendingworkstmt="select * from checkerportal where result='R'";
			
			
			return jdbctemplate.query(pendingworkstmt, new RejectedListMapper());

		}

		 class RejectedListMapper implements RowMapper<Checkerportal>{
			 
			 @Override
			 public Checkerportal mapRow(ResultSet rs,int rowNum) throws SQLException{
				 Checkerportal pending=new Checkerportal();
				 
				 pending.setRequestid(rs.getInt("requestid"));
				 pending.setCustomerid(rs.getString("customerid"));
				 pending.setCustomer(rs.getString("customer"));
				 pending.setResult(rs.getString("result"));
				 pending.setRequested(rs.getString("requested"));
				 pending.setCheckercomment(rs.getString("checkercomment"));
					
				return pending;
				 
			 }
		 }



		@Override
		public int changeRequestedStatus(Checkerportal cp) {
			String requestToChecker="update checkerportal set result=null,requested='N' where customer='"+cp.getCustomer()+"'";
			
			return jdbctemplate.update(requestToChecker);
		}

	
}
