package com.scb.newton.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.newton.bean.AccountsInfo;
import com.scb.newton.bean.GroupsInfo;
import com.scb.newton.dao.GroupForAccountsDao;

@Service
public class GroupForAccountsServiceImpl implements GroupsForAccountsService{

	@Autowired
	GroupForAccountsDao gfadao;
	
	


	@Override
	public int updateGroupWithAccountId(AccountsInfo ai) {
		// TODO Auto-generated method stub
		return gfadao.updateGroupWithAccountId(ai);
	}




	@Override
	public List<AccountsInfo> getAccountDataInState(AccountsInfo ai) {
		// TODO Auto-generated method stub
		return gfadao.getAccountDataInState(ai);
	}
	
	@Override
	public List<GroupsInfo> getGroupDataInState(GroupsInfo ai) {
		// TODO Auto-generated method stub
		return gfadao.getGroupDataInState(ai);
	}

}
