package com.scb.newton.bean;

public class Checkerportal {

	private int requestid;
	private String customerid;
	private String customer;
	private String result;
	private String requested;
	private String checkercomment;
	public int getRequestid() {
		return requestid;
	}
	public void setRequestid(int requestid) {
		this.requestid = requestid;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getRequested() {
		return requested;
	}
	public void setRequested(String requested) {
		this.requested = requested;
	}
	public String getCheckercomment() {
		return checkercomment;
	}
	public void setCheckercomment(String checkercomment) {
		this.checkercomment = checkercomment;
	}
	
}
