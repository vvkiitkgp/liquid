package com.scb.newton.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.scb.newton.bean.AccountsInfo;
import com.scb.newton.bean.GroupsInfo;
import com.scb.newton.service.GroupsForAccountsService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class AccountsInfoController {

	
	@Autowired
	GroupsForAccountsService gfaser;
	
	@PutMapping("/updateGroupWithAccountId/{groupID}/{accountID}")
	public int updateGroupWithAccountId(@PathVariable String groupID,@PathVariable String accountID)
	{AccountsInfo ai=new AccountsInfo();
	ai.setGroupId(groupID);
	ai.setAccountId(accountID);
		return gfaser.updateGroupWithAccountId(ai);
	}
	
	@GetMapping("/getAccountDataInState/{customer}")
	public List<AccountsInfo> getAccountDataInState(@PathVariable String customer)
	{
		AccountsInfo ai=new AccountsInfo();
		ai.setCustomer(customer);
		return gfaser.getAccountDataInState(ai);
	}
	
	@GetMapping("/getGroupDataInState/{customer}")
	public List<GroupsInfo> getGroupDataInState(@PathVariable String customer)
	{
			GroupsInfo ai=new GroupsInfo();
		ai.setCustomer(customer);
		
		return gfaser.getGroupDataInState(ai);
	}
	
	
}
