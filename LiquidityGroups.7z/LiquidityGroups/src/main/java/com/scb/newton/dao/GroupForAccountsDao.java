package com.scb.newton.dao;

import java.util.List;

import com.scb.newton.bean.AccountsInfo;
import com.scb.newton.bean.Checkerportal;
import com.scb.newton.bean.GroupsInfo;

public interface GroupForAccountsDao {

	 public int updateGroupWithAccountId(AccountsInfo ai);
	 
	public List<AccountsInfo>  getAccountDataInState(AccountsInfo ai);
	
	public List<GroupsInfo>  getGroupDataInState(GroupsInfo ai);
	
	public int addGroupButtonHandler(GroupsInfo gi);
	
	public List<Checkerportal>  getPendingWork(Checkerportal cp);

	public int changeRequestedStatus(Checkerportal cp);
}
