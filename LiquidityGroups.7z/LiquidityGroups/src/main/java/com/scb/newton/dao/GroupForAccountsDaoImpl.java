package com.scb.newton.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import org.springframework.stereotype.Repository;


import com.scb.newton.bean.AccountsInfo;
import com.scb.newton.bean.GroupsInfo;

@Repository
public class GroupForAccountsDaoImpl implements GroupForAccountsDao{

	@Autowired
	JdbcTemplate jdbctemplate;
	

	@Override
	public int updateGroupWithAccountId(AccountsInfo ai) {
	String onHitParticularGroupHandlerstmt="update \"accountInfo\" set \"groupId\"=? where \"accountId\"=? ";
		
		return jdbctemplate.update(onHitParticularGroupHandlerstmt,new Object[]{ai.getGroupId(),ai.getAccountId()});
	}


	@Override
	public List<AccountsInfo> getAccountDataInState(AccountsInfo ai)
	{
		
		String listGroupsForAccountsQuery="select * from \"accountInfo\" where customer='"+ai.getCustomer()+"';  ";
		
		
		return jdbctemplate.query(listGroupsForAccountsQuery, new AccountsMapper());

	}

	 class AccountsMapper implements RowMapper<AccountsInfo>{
		 
		 @Override
		 public AccountsInfo mapRow(ResultSet rs,int rowNum) throws SQLException{
			 AccountsInfo accinfo=new AccountsInfo();
			 
			 	accinfo.setAccountId(rs.getString("accountId"));
			 	accinfo.setGroupId(rs.getString("groupId"));
			 	accinfo.setActiveAccount(rs.getBoolean("activeAccount"));
			 	accinfo.setCustomer(rs.getString("customer"));
			 	accinfo.setNumberOfTransactions(rs.getInt("numberOfTransactions"));
				accinfo.setTotalBalance(rs.getDouble("totalBalance"));
				accinfo.setCurrency(rs.getString("currency"));
				accinfo.setBaseAccountBoolean(rs.getBoolean("baseAccountBoolean"));
				return accinfo;
			 
		 }
	 }		
	 
	 
	 
	 @Override
		public List<GroupsInfo> getGroupDataInState(GroupsInfo ai)
		{
			
			String listGroupsForAccountsQuery="select * from \"groupInfo\" where customer='"+ai.getCustomer()+"';  ";
			
			
			return jdbctemplate.query(listGroupsForAccountsQuery, new GroupsMapper());

		}

		 class GroupsMapper implements RowMapper<GroupsInfo>{
			 
			 @Override
			 public GroupsInfo mapRow(ResultSet rs,int rowNum) throws SQLException{
				 GroupsInfo grpinfo=new GroupsInfo();
				 
				 
				 	grpinfo.setGroupId(rs.getString("groupId"));
				 	grpinfo.setProductId(rs.getString("productId"));
				 	grpinfo.setBonusStatus(rs.getString("bonusStatus"));
				 	grpinfo.setBonusValue(rs.getDouble("bonusValue"));
				 	grpinfo.setBaseCurrency(rs.getString("baseCurrency"));
				 	grpinfo.setBaseAccount(rs.getString("baseAccount"));
				 	grpinfo.setCustomer(rs.getString("customer"));
				
					
					return grpinfo;
				 
			 }
		 }	
	
}
